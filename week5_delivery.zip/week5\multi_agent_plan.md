Week 5 Multi-Agent Plan

Objective:
- Build orchestrator + supervisor to coordinate Researcher, Analyst, and Writer agents.
- Implement message passing, role assignment, and evaluation loop (use ResearchEvaluator).

Phases:
1. Design: define agent roles, messages, and success criteria.
2. Implement supervisor skeleton and message queue.
3. Integrate skills from `reference-repositories/agent_skills/`.
4. Add evaluation harness (pairwise and aggregate scoring).
5. Run benchmarks and iterate.

Deliverables:
- `week5/agent_supervisor.py` starter code
- Example scenario YAMLs under `week5/scenarios/`
- E2E test that runs small 3-agent workflow locally with `--local-test` mode
