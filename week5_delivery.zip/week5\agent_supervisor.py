"""
Starter Supervisor for multi-agent orchestration (Week 5 scaffold).
This is a lightweight entrypoint demonstrating how to spawn agents and pass messages.
Run in local-test mode for offline testing.
"""
import asyncio
from typing import Dict, Any

class Supervisor:
    def __init__(self):
        self.agents = {}

    def register(self, name: str, handler):
        self.agents[name] = handler

    async def send(self, to: str, message: str) -> Any:
        handler = self.agents.get(to)
        if not handler:
            raise ValueError(f"Unknown agent: {to}")
        # handler can be async callable
        if asyncio.iscoroutinefunction(handler):
            return await handler(message)
        else:
            return handler(message)

async def demo():
    sup = Supervisor()

    async def researcher(msg):
        await asyncio.sleep(0.05)
        return f"researcher processed: {msg}"

    async def writer(msg):
        await asyncio.sleep(0.02)
        return f"writer produced: {msg}"

    sup.register('researcher', researcher)
    sup.register('writer', writer)

    res = await sup.send('researcher', 'Explore caching benefits')
    print('researcher ->', res)
    out = await sup.send('writer', res)
    print('writer ->', out)

if __name__ == '__main__':
    asyncio.run(demo())
