"""Integrated TokenTracker wrapper with lightweight tests and CLI."""
import sys
from pathlib import Path
import json

# Add experiments folder to path
exp = Path(__file__).resolve().parents[1] / 'reference-repositories' / 'experiments'
if str(exp) not in sys.path:
    sys.path.insert(0, str(exp))

# Implement a lightweight TokenTracker here to avoid heavy external deps
from dataclasses import dataclass, field
from datetime import datetime
from typing import List

@dataclass
class TokenUsage:
    input_tokens: int
    output_tokens: int
    model: str
    agent: str
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    def to_dict(self):
        return {
            'input_tokens': self.input_tokens,
            'output_tokens': self.output_tokens,
            'model': self.model,
            'agent': self.agent,
            'timestamp': self.timestamp
        }

class TokenTracker:
    def __init__(self, history_file: Path = None, budget: int = None):
        self.history_file = history_file or (Path(__file__).resolve().parents[1] / 'research_data' / 'token_history.json')
        self.budget = budget
        self.session_usage: List[TokenUsage] = []
        self.session_start = datetime.now()
        self.history = {'sessions': []}
        try:
            self.history_file.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

    def track(self, response, agent: str = 'unknown') -> TokenUsage:
        # response must have `.usage.input_tokens` and `.usage.output_tokens` or be a dict
        if hasattr(response, 'usage'):
            usage = response.usage
            input_t = getattr(usage, 'input_tokens', 0)
            output_t = getattr(usage, 'output_tokens', 0)
        elif isinstance(response, dict):
            input_t = response.get('input_tokens', 0)
            output_t = response.get('output_tokens', 0)
        else:
            input_t = 0
            output_t = 0

        tu = TokenUsage(input_tokens=input_t, output_tokens=output_t, model=getattr(response, 'model', 'unknown'), agent=agent)
        self.session_usage.append(tu)
        return tu

    @property
    def total_input_tokens(self) -> int:
        return sum(u.input_tokens for u in self.session_usage)

    @property
    def total_output_tokens(self) -> int:
        return sum(u.output_tokens for u in self.session_usage)

    def _save_history(self):
        try:
            self.history['sessions'].append({'start': self.session_start.isoformat(), 'usage': [u.to_dict() for u in self.session_usage]})
            with open(self.history_file, 'w') as f:
                import json
                json.dump(self.history, f, indent=2)
        except Exception:
            pass

    def report_session(self):
        return {
            'total_input_tokens': self.total_input_tokens,
            'total_output_tokens': self.total_output_tokens,
            'calls': len(self.session_usage)
        }


# Minimal mock response for testing
class MockUsage:
    def __init__(self, input_tokens, output_tokens):
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens

class MockResponse:
    def __init__(self, input_t, output_t, model='test-model'):
        self.usage = MockUsage(input_t, output_t)
        self.model = model


def run_quick_test():
    tt = TokenTracker(budget=1000000)
    resp1 = MockResponse(120, 300)
    resp2 = MockResponse(10, 50)
    resp3 = MockResponse(500, 800)
    tt.track(resp1, agent='researcher')
    tt.track(resp2, agent='analyst')
    tt.track(resp3, agent='writer')
    report = tt.report_session()
    print(json.dumps(report, indent=2))
    tt._save_history()


if __name__ == '__main__':
    run_quick_test()
